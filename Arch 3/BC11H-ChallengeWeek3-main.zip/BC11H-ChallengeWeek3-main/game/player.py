import math
import time

import pygame
from pygame.surface import Surface
from game.camera import Camera
from game import config
from game import powerup
from util.eventHandler import EventManager, RespawnEvent, FinishEvent
from game.display import Display


class Player:
    def __init__(self, config: config, name, description, position, player_sprite):
        self.config = config
        self.name = name
        self.description = description
        self.position = [*position]  # to make sure it's an array
        self.display = Display()
        self.player_sprite = player_sprite
        self.num_sprites = 0
        self.finish_event = FinishEvent(
            None, config.PLAYER_POSITION, config.FINISH_SOUND
        )
        self.POWERUP_RESPAWN_TIME = 5000
        self.powerup_respawn_time = None
        self.item_inventory = []

        self.left = None
        self.right = None
        self.up = None
        self.down = None
        self.boost = None

    def prepare(self, frame=0):
        game_image = pygame.image.load(self.player_sprite).convert_alpha()
        sprite_width = config.PLAYER_SPRITE_WIDTH
        sprite_height = config.PLAYER_SPRITE_HEIGHT
        num_sprites = game_image.get_width() // sprite_width
        self.num_sprites = num_sprites
        sprites = []
        for i in range(num_sprites):
            sprite_x = i * sprite_width
            sprite = game_image.subsurface(
                pygame.Rect((sprite_x, 0, sprite_width, sprite_height))
            )
            sprite = pygame.transform.scale(
                sprite,
                (
                    sprite_width * config.PLAYER_SPRITE_SCALE,
                    sprite_height * config.PLAYER_SPRITE_SCALE,
                ),
            )
            sprites.append(sprite)
        return self.check_flip(sprites[frame])

    def move(
        self,
        screen: Surface,
        camera: Camera,
        controls: list,
        current_position: list[int],
        powerup_list: pygame.sprite.Group,
        is_controller: bool,
    ):
        print("Controls: ", controls)
        if is_controller:
            self.left = controls[1]
            self.right = controls[0]
            self.up = controls[3]
            self.down = controls[2]
            self.boost = controls[4]
        else:
            self.left = controls[pygame.K_a] or controls[pygame.K_LEFT]
            self.right = controls[pygame.K_d] or controls[pygame.K_RIGHT]
            self.up = controls[pygame.K_w] or controls[pygame.K_UP]
            self.down = controls[pygame.K_s] or controls[pygame.K_DOWN]
            self.boost = controls[pygame.K_LSHIFT] or controls[pygame.K_RSHIFT]

        print(self.left, self.right, self.up, self.down, self.boost)

        self.display.dt = config.SECONDS_PER_FRAME

        player_rect = pygame.Rect(
            current_position,
            (config.PLAYER_SPRITE_WIDTH, config.PLAYER_SPRITE_HEIGHT),
        )

        player_speed = config.PLAYER_CURRENT_SPEED

        player_acceleration = config.PLAYER_MAX_SPEED
        player_friction = config.PLAYER_FRICTION

        frame_idle = self.num_sprites // 2
        current_frame = frame_idle
        frame_delta = 1 if self.left or self.right else 0

        initial_player_speed = player_speed

        # Check if player is on a powerup and update accordingly
        items = powerup.Powerup(-1).update(player_rect, powerup_list)
        if items:
            self.item_inventory.extend(items)

        if initial_player_speed <= config.PLAYER_MAX_SPEED:
            player_speed = (
                initial_player_speed + player_acceleration * self.display.dt
            ) * player_friction

        if self.up:
            self.position[1] -= player_speed * config.SECONDS_PER_FRAME
            current_frame = 0
        if self.down:
            self.position[1] += player_speed * config.SECONDS_PER_FRAME
            current_frame = 10
        if self.left:
            config.PLAYER_SPRITE_HORIZONTAL_FLIP = True
            self.position[0] -= player_speed * config.SECONDS_PER_FRAME
            current_frame = min(current_frame + frame_delta, self.num_sprites - 4)
        if self.right:
            config.PLAYER_SPRITE_HORIZONTAL_FLIP = False
            self.position[0] += player_speed * config.SECONDS_PER_FRAME
            current_frame = min(current_frame + frame_delta, self.num_sprites - 4)

        player_rect.x = self.position[0] + config.MAP_POSITION[0]
        player_rect.y = self.position[1] + config.MAP_POSITION[1]

        store_speed = player_speed
        if (self.boost or controls[4]) and self.item_inventory is not None:
            print("Using powerup!")
            if "Boost" in self.item_inventory:
                player_speed = player_speed * 3
            elif "Slow" in self.item_inventory:
                player_speed = player_speed / 5

        else:
            for event in pygame.event.get(pygame.KEYUP):
                if event.type == pygame.KEYUP or event.type == pygame.JOYAXISMOTION:
                    if (
                        event.key == pygame.K_LSHIFT
                        or event.key == pygame.K_RSHIFT
                        or controls[4] is True
                    ):
                        if "Boost" in self.item_inventory:
                            self.item_inventory.remove("Boost")
                        elif "Slow" in self.item_inventory:
                            self.item_inventory.remove("Slow")
            player_speed = store_speed

        if (self.up or self.down) and (self.left or self.right):
            player_speed = player_speed / math.sqrt(2)

        any_keys = self.up or self.down or self.left or self.right

        if not any_keys:
            player_speed = 0
            config.PLAYER_CURRENT_FRAME = frame_idle

        config.PLAYER_CURRENT_SPEED = round(player_speed, 0)
        config.PLAYER_CURRENT_FRAME = current_frame

        screen_rect = pygame.Rect(
            0,
            0,
            config.SCREEN_WIDTH - config.PLAYER_SPRITE_WIDTH,
            config.SCREEN_HEIGHT - config.PLAYER_SPRITE_HEIGHT,
        )

        player_rect, screen_rect = camera.do_movement(
            player_rect, screen_rect, powerup_list
        )

        (
            current_position[0],
            current_position[1],
        ) = player_rect.topleft

        screen.blit(self.prepare(current_frame), current_position)

    def check_for_events(
        self, screen: Surface, map_rects: list[pygame.Rect], current_position
    ):
        # Create event manager
        event_manager = EventManager()

        # Create respawn event
        respawn_event = RespawnEvent(
            map_rects,
            current_position,
            config.RESPAWN_SOUND,
        )

        # Create finish event
        self.finish_event.player_position = current_position
        self.finish_event.screen = screen

        # Register events
        event_manager.register_event(respawn_event)
        event_manager.register_event(self.finish_event)

        # Trigger events, if any pass
        event_manager.trigger_events()

    def check_flip(self, player):
        if config.PLAYER_SPRITE_HORIZONTAL_FLIP or config.PLAYER_SPRITE_VERTICAL_FLIP:
            player = pygame.transform.flip(
                surface=player,
                flip_x=config.PLAYER_SPRITE_HORIZONTAL_FLIP,
                flip_y=config.PLAYER_SPRITE_VERTICAL_FLIP,
            )
        return player

    def reset(self):
        config.PLAYER_CURRENT_POSITION = config.PLAYER_RESPAWN_POSITION[:]
        config.PLAYER_POSITION = config.PLAYER_CURRENT_POSITION[:]
        config.PLAYER_CURRENT_SPEED = 0
        config.RACE_CURRENT_LAP = 0

    def print_config(self):
        if self.config is None:
            print("Config is None")
            return False
        else:
            for var_name in dir(self.config):
                if var_name.isupper():
                    if var_name.startswith("PLAYER_"):
                        print(f"{var_name}: {getattr(self.config, var_name)}")
